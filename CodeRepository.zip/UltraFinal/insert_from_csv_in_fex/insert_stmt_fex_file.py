#!/usr/bin/env python
# standard imports
import sys
from pathlib import Path
from collections import deque
# third party imports
import pandas as pd

def get_stmt_to_insert(hold_name, fileout_name):
    stmt_to_insert = (
        f"-*===================================================================== csv create\n"
        f"-SET &HOLD_NAME     = '{hold_name}';\n"
        f"-SET &FILE_OUT_NAME = '{fileout_name}';\n"
        f"-MRNOEDIT -INCLUDE operations_analytics/utility_csv_test/csv_create.fex\n"
        f"-GOTO ::END_CSV_OUTPUT;\n"
        f"-*=====================================================================\n"
    )
    return stmt_to_insert

def get_end_csv_output_lines():
    return (
        f"-*=====================================================================\n"
        f"-::END_CSV_OUTPUT\n"
        f"-*=====================================================================\n"
    )

def get_full_stmt(hold_name, fileout_name):
    return get_stmt_to_insert(hold_name, fileout_name) + get_end_csv_output_lines()

def option1(fex_filepath, hold_name):
    # get stmt to insert
    before_table_file_stmt = get_stmt_to_insert(hold_name, Path(fex_filepath).stem)
    after_last_end_stmt = get_end_csv_output_lines()

    # read fex file and insert stmt BEFORE latest 'TABLE FILE' stmt and AFTER latest 'END' stmt
    file_as_str_list = deque()
    found_last_table_file = False
    found_last_iteration_end = False

    for line in reversed(open(Path(fex_filepath)).readlines()):
        if not found_last_iteration_end and not line.startswith('-*') and 'END' in line:
            [file_as_str_list.appendleft(stmt_line + '\n') for stmt_line in reversed(after_last_end_stmt.splitlines())]
            found_last_iteration_end = True
            file_as_str_list.appendleft(line)
        elif not found_last_table_file and not line.startswith('-*') and 'TABLE FILE' in line:
            file_as_str_list.appendleft(line)
            [file_as_str_list.appendleft(stmt_line + '\n') for stmt_line in reversed(before_table_file_stmt.splitlines())]
            found_last_table_file = True
        else:
            file_as_str_list.appendleft(line)

    # read the file in write mode
    with open(Path(fex_filepath), "w") as fout:
        for line in file_as_str_list:
            fout.write(line)


def option2(fex_filepath, hold_name):
    # get stmt to insert
    stmt_to_insert = get_full_stmt(hold_name, Path(fex_filepath).stem)

    file_as_str_list = deque()
    found_last_iteration_end = False
    # read file and append new stmt AFTER latest 'END' stmt
    for line in reversed(open(Path(fex_filepath)).readlines()):
        if not found_last_iteration_end and not line.startswith('-*') and 'END' in line:
            [file_as_str_list.appendleft(stmt_line + '\n') for stmt_line in reversed(stmt_to_insert.splitlines())]
            found_last_iteration_end = True
        file_as_str_list.appendleft(line)

    # rewrite file with new insertions
    with open(Path(fex_filepath), "w") as fout:
        for line in file_as_str_list:
            fout.write(line)

if __name__ == '__main__':
    """
    Process to add different statements on the .fex files provided on the references.csv
    """
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} [PATH_TO_REF_CSV]")
        exit(-1)

    references_df = pd.read_csv(sys.argv[1], dtype=str)

    for row in references_df.itertuples():
        fex_filepath = row.FEX_PATH_NAME
        hold_name = row.HOLD_NAME
        if row.AUTO_IND == '0':
            # option 2
            # everything after the lastest 'END' operator 
            print(fex_filepath, hold_name)
            option2(fex_filepath, hold_name)
        elif row.AUTO_IND == '1':
            # option 1
            # insert stmt BEFORE latest 'TABLE FILE' stmt and AFTER latest 'END' stmt
            print(fex_filepath, hold_name)
            option1(fex_filepath, hold_name)
    exit(0)