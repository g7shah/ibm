import sys
import os
import pandas as pd
import itertools


##Main Function##
if __name__ == "__main__":

    df=pd.DataFrame(columns=['File Name','DEFINE FILE TABLE FILE Name'])
    i = 0
    #os.system('find . | grep -E "(__pycache__|\.pyc|\.pyo$)" | xargs rm -rf')


    if len(sys.argv) != 2:
        print('\n!Error: File list Path not provided\n')
        sys.exit(1)
    directory = sys.argv[1].strip()

    #file_list.remove('Table_list.csv')

    # if not file_list:
    #     print('\n!Error: There is no file process\n')
    #     sys.exit(1)

    for root, subdirectories, files in os.walk(directory):
        for subdirectory in subdirectories:
            # just to keep track of folder names and directories that we are in
            (os.path.join(root, subdirectory))
            #print(root)
    #         print(subdirectory)
    #     print(files)

        for fl in files:
            print(fl)
            if fl.endswith('.DS_Store'):
                continue
            if not fl.endswith('.fex'):
                continue
            table_list = []
            data = {}
            final_table_list = []
            final_table_string = ''
            fp = open(os.path.join(root, fl), "rt")
            lines = fp.readlines()
            table_list= []
            for line in lines:
                if line.startswith('-*'):
                    continue
                if ('TABLE FILE' in line.strip().upper()) or ('DEFINE FILE' in line.strip().upper()):
                    table_list.append(line.split(' ')[2])
                    table_list = list(map(lambda x:x.strip(),table_list))
                    table_list = list(dict.fromkeys(table_list))

            # final_table_list = list(itertools.chain(*table_list))
            # final_table_string = ','.join(final_table_list)

                    df.loc[i] = [root + '/' + fl] + table_list
                    table_list = []
                    i += 1
                fp.close

    df.to_csv(directory+'/Table_list.csv', sep=',', index=False,header=True)
    print("\nTable list file generated within %s directory\n"%directory)
