import sys
import os

def find_nth(haystack, needle, n):
    start = haystack.find(needle)
    while start >= 0 and n > 1:
        start = haystack.find(needle, start+len(needle))
        n -= 1
    return start

if __name__ == "__main__":

    if len(sys.argv) != 2:
        print('\n!Error: File list Path not provided\n')
        sys.exit(1)
    directory = sys.argv[1].strip()


    for root, subdirectories, files in os.walk(directory):
        for subdirectory in subdirectories:
            # just to keep track of folder names and directories that we are in
            (os.path.join(root, subdirectory))
        for file in files:
            # FOR ACX files, we change 'CONNECTION' name only. And for each file there exists only 1 connection name
            if file.endswith(".mas"):
                fin = open(os.path.join(root, file), "rt")
                data = fin.readlines()

                for i in range(len(data)):
                    if 'ALIAS=' in data[i]:
                        #print(i)
                        stp = data[i].find('ALIAS=')
                        stp += 6
                        endp = find_nth(data[i],',',2)
                        data[i] = data[i].replace(data[i][stp:endp],data[i][stp:endp].upper())
                        #print(i)
                #print(data)
                string = ' '.join([str(elem) for elem in data])

                fout = open(os.path.join(root, file), "wt")

    #         #overrite the input file with the resulting data
                fout.write(string)
    #         #close the file
                fout.close()
