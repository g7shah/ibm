import pandas as pd
import re
import os


def process_sql_file(file_name):
    file, string = open(file_name, "r"), ''

    # for line in file, remove comments, space out '(' and ')', add line to output string:
    for line in file:
        line = line.rstrip()
        line = line.split('//')[0]
        line = line.split('--')[0]
        line = line.split('#')[0]
        line = line.split('-')[0]
        line = line.split('-*')[0]
        line = line.replace('(', ' ( ')
        line = line.replace(')', ' ) ')
        string += ' ' + line
    file.close()

    # remove multi-line comments:
    while string.find('/*') > -1 and string.find('*/') > -1:
        l_multi_line = string.find('/*')
        r_multi_line = string.find('*/')
        string = string[:l_multi_line] + string[r_multi_line + 2:]

    # remove extra whitespaces and make list
    words = string.split()
    #print(words)

    return words


def find_table_names(words):
    table_names = set()
    previous_word = None

    for word in words:
        if previous_word == 'from' or previous_word == 'join' or previous_word == 'FROM' or previous_word == 'JOIN':
            if word != '(' and word.isnumeric() == False and word not in ('INNER', 'LEFT_OUTER', 'CHARACTER_LENGTH'):
                table_names.add(word)
        previous_word = word

    return sorted(list(table_names))


#  this function assumes that the .sql file does not have any syntax errors:
def find_table_names_from_sql_file(file_name):
    words = process_sql_file(file_name)
    return find_table_names(words)


if __name__ == '__main__':

    if len(sys.argv) != 2:
        print('\n!Error: File list Path not provided\n')
        sys.exit(1)


    directory = sys.argv[1].strip()

    if not directory:
        print('\n!Error: There is no file process\n')
        sys.exit(1)

    for root, subdirectories, files in os.walk(directory):
        for subdirectory in subdirectories:
            print((os.path.join(root, subdirectory)))

    headers = ['File Path', 'File Name', 'Table Names']
    df_final = pd.DataFrame(columns=headers)

    for file in files:
        if file != '.DS_Store':
            file_path = root + '/' + file
            All_Table_List = find_table_names_from_sql_file(file_path)

            All_Table_List_Unique = list(set(All_Table_List))
            num_tables = len(All_Table_List_Unique)

            file_path_lst = [root] * num_tables
            file_name_lst = [file] * num_tables
            data_tuples = list(zip(file_path_lst, file_name_lst, All_Table_List_Unique))
            df = pd.DataFrame(data_tuples, columns=headers)
            df_final = df_final.append(df, ignore_index=True)

    df_final.to_csv(directory + '/output_tabel_names.csv', index=False)
